package com.example.minimarket.publisher

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Публикация приложения в личный каталог:
 * 1) создаёт релиз в вашем репозитории GitHub,
 * 2) загружает туда APK,
 * 3) добавляет запись в catalog.json (его читает приложение Mini Market).
 */
class PublisherActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("publisher", MODE_PRIVATE) }

    private lateinit var repoField: EditText
    private lateinit var tokenField: EditText
    private lateinit var nameField: EditText
    private lateinit var descField: EditText
    private lateinit var versionField: EditText
    private lateinit var fileInfo: TextView
    private lateinit var status: TextView
    private lateinit var progress: LinearProgressIndicator
    private lateinit var publishBtn: MaterialButton

    private var pickedUri: Uri? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pickedUri = uri
            fileInfo.text = queryName(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_publisher)

        repoField = findViewById(R.id.repoField)
        tokenField = findViewById(R.id.tokenField)
        nameField = findViewById(R.id.nameField)
        descField = findViewById(R.id.descField)
        versionField = findViewById(R.id.versionField)
        fileInfo = findViewById(R.id.fileInfo)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        publishBtn = findViewById(R.id.publishBtn)

        repoField.setText(prefs.getString("repo", "psaiddavron/Bavikstor"))
        tokenField.setText(prefs.getString("token", ""))

        findViewById<View>(R.id.pickBtn).setOnClickListener { picker.launch(arrayOf("*/*")) }
        publishBtn.setOnClickListener { publish() }
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return "app.apk"
    }

    private fun say(text: String) {
        ui.post { status.text = text }
    }

    private fun complete(text: String) {
        publishBtn.isEnabled = true
        progress.visibility = View.GONE
        status.text = text
    }

    private fun publish() {
        val repo = repoField.text.toString().trim()
        val token = tokenField.text.toString().trim()
        val appName = nameField.text.toString().trim()
        val appDesc = descField.text.toString().trim()
        val appVer = versionField.text.toString().trim()
        val uri = pickedUri

        if (repo.isEmpty() || token.isEmpty() || appName.isEmpty() || uri == null) {
            status.text = "Заполните репозиторий, токен, название и выберите APK"
            return
        }
        prefs.edit().putString("repo", repo).putString("token", token).apply()

        publishBtn.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.setProgressCompat(0, false)

        thread {
            try {
                say("Копирую файл…")
                val file = File(cacheDir, "upload.apk")
                val input = contentResolver.openInputStream(uri) ?: throw Exception("Не удалось открыть файл")
                input.use { i -> file.outputStream().use { o -> i.copyTo(o) } }
                if (file.length() == 0L) throw Exception("Файл пустой")

                val ts = System.currentTimeMillis() / 1000

                say("Создаю релиз…")
                val rel = JSONObject()
                    .put("tag_name", "app-$ts")
                    .put("name", "$appName $appVer".trim())
                    .put("body", appDesc)
                val (c1, t1) = api("POST", "https://api.github.com/repos/$repo/releases", token, rel.toString())
                if (c1 !in 200..299) throw Exception("Релиз: HTTP $c1 ${errMsg(t1)}")
                val releaseId = JSONObject(t1).getLong("id")

                say("Загружаю APK…")
                val apkUrl = upload(repo, releaseId, "app-$ts.apk", file, token)

                say("Обновляю каталог…")
                updateCatalog(repo, token, appName, appDesc, appVer, apkUrl)

                ui.post { complete("Готово! «$appName» добавлено в каталог.") }
            } catch (e: Exception) {
                ui.post { complete("Ошибка: ${e.message}") }
            }
        }
    }

    private fun connect(method: String, url: String, token: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.setRequestProperty("User-Agent", "MiniMarketPublisher")
        return c
    }

    private fun api(method: String, url: String, token: String, body: String?): Pair<Int, String> {
        val c = connect(method, url, token)
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, text)
    }

    private fun errMsg(text: String): String =
        try {
            JSONObject(text).optString("message", text)
        } catch (e: Exception) {
            text.take(120)
        }

    /** Загружает APK как файл релиза и возвращает прямую ссылку на скачивание. */
    private fun upload(repo: String, releaseId: Long, assetName: String, file: File, token: String): String {
        val c = connect("POST", "https://uploads.github.com/repos/$repo/releases/$releaseId/assets?name=$assetName", token)
        val total = file.length()
        c.doOutput = true
        c.readTimeout = 120_000
        c.setFixedLengthStreamingMode(total)
        c.setRequestProperty("Content-Type", "application/vnd.android.package-archive")

        var sent = 0L
        var last = -1
        file.inputStream().use { input ->
            c.outputStream.use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    sent += n
                    val pct = (sent * 100 / total).toInt()
                    if (pct != last) {
                        last = pct
                        ui.post { progress.setProgressCompat(pct, true) }
                    }
                }
            }
        }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("Загрузка: HTTP $code ${errMsg(text)}")
        return JSONObject(text).getString("browser_download_url")
    }

    /** Добавляет (или заменяет по названию) запись в catalog.json в корне репозитория. */
    private fun updateCatalog(
        repo: String, token: String,
        appName: String, appDesc: String, appVer: String, apkUrl: String
    ) {
        val url = "https://api.github.com/repos/$repo/contents/catalog.json"
        val (code, text) = api("GET", url, token, null)

        var sha: String? = null
        var old = JSONArray()
        if (code == 200) {
            val o = JSONObject(text)
            sha = o.getString("sha")
            val raw = String(Base64.decode(o.getString("content"), Base64.DEFAULT), Charsets.UTF_8)
            if (raw.isNotBlank()) old = JSONArray(raw)
        } else if (code != 404) {
            throw Exception("Каталог: HTTP $code ${errMsg(text)}")
        }

        val items = JSONArray()
        for (i in 0 until old.length()) {
            val e = old.getJSONObject(i)
            if (e.optString("name") != appName) items.put(e)
        }
        items.put(
            JSONObject()
                .put("name", appName)
                .put("description", appDesc)
                .put("version", appVer)
                .put("apk", apkUrl)
        )

        val body = JSONObject()
            .put("message", "Add $appName $appVer".trim())
            .put("content", Base64.encodeToString(items.toString(2).toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
        if (sha != null) body.put("sha", sha)

        val (c2, t2) = api("PUT", url, token, body.toString())
        if (c2 !in 200..299) throw Exception("Каталог: HTTP $c2 ${errMsg(t2)}")
    }
}
