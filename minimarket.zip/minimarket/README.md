# Mini Market

Два приложения для Android:

- **Mini Market** (`app-debug.apk`) для обычных людей: показывает каталог и устанавливает приложения.
- **Publisher** (`publisher-debug.apk`) для вас: выбираете APK, пишете название, и он добавляет приложение в каталог.

Каталог хранится в вашем репозитории GitHub (`catalog.json`), файлы APK лежат в его Releases. Репозиторий должен быть публичным.

Используйте только свои приложения, игры, которые вы разрабатываете или которые распространяются свободно.

## Сборка

Загрузите `minimarket.zip` в корень репозитория, а `.github/workflows/build.yml` создайте как описано в чате. Сборка запускается сама, APK появятся в Releases.

## Токен для Publisher

GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token:
- Repository access: Only select repositories → ваш репозиторий.
- Permissions → Repository permissions → Contents: Read and write.

Вставьте токен в Publisher. Никому его не показывайте и не отдавайте приложение Publisher другим людям.

## Как пользоваться

1. В Publisher: название, описание, версия, «Выбрать APK», «Опубликовать».
2. Люди открывают Mini Market и нажимают «Обновить». Каталог подтягивается сам (кэш GitHub может обновляться до 5 минут).
